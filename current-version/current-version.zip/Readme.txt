To run the program just make a double click on the .jar file or in the command line (via console) execute the next command:

java -jar "KOTDD.jar"

Note: Obviously, the command has to be executed when located in the same folder as the .jar file.